package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.edu.mathapp.R;

public class UnitActivity extends AppCompatActivity {

    private String grade, part;
    private int partNumber;

    private static final String[][] UNIT_NAMES = {
        // Part 1 units
        {
            "الحساب والجبر",
            "المعادلات والمتباينات",
            "الدوال والرسوم البيانية",
            "المثلثات",
            "الهندسة التحليلية",
            "حساب التفاضل",
            "حساب التكامل"
        },
        // Part 2 units
        {
            "التوبولوجيا والفضاء",
            "نظرية الأعداد",
            "الاحتمالات والإحصاء",
            "المصفوفات والمحددات",
            "المتسلسلات والمتتاليات",
            "الأعداد المركبة",
            "التحليل الرياضي"
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit);

        grade = getIntent().getStringExtra("grade");
        part = getIntent().getStringExtra("part");
        partNumber = getIntent().getIntExtra("partNumber", 1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(part);
        }

        TextView tvPartTitle = findViewById(R.id.tv_part_title);
        tvPartTitle.setText(grade + " - " + part);

        setupUnitCards();
    }

    private void setupUnitCards() {
        int[] cardIds = {
            R.id.card_unit1, R.id.card_unit2, R.id.card_unit3, R.id.card_unit4,
            R.id.card_unit5, R.id.card_unit6, R.id.card_unit7
        };
        int[] tvIds = {
            R.id.tv_unit1_name, R.id.tv_unit2_name, R.id.tv_unit3_name, R.id.tv_unit4_name,
            R.id.tv_unit5_name, R.id.tv_unit6_name, R.id.tv_unit7_name
        };

        String[] unitNames = UNIT_NAMES[partNumber - 1];

        for (int i = 0; i < 7; i++) {
            CardView card = findViewById(cardIds[i]);
            TextView tvName = findViewById(tvIds[i]);
            tvName.setText(unitNames[i]);
            final int unitNum = i + 1;
            final String unitName = unitNames[i];
            card.setOnClickListener(v -> {
                Intent intent = new Intent(this, LessonActivity.class);
                intent.putExtra("grade", grade);
                intent.putExtra("part", part);
                intent.putExtra("partNumber", partNumber);
                intent.putExtra("unitNumber", unitNum);
                intent.putExtra("unitName", unitName);
                startActivity(intent);
            });
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
