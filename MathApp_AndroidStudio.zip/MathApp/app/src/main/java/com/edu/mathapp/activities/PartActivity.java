package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.edu.mathapp.R;

public class PartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part);

        String grade = getIntent().getStringExtra("grade");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(grade);
        }

        TextView tvGradeTitle = findViewById(R.id.tv_grade_title);
        tvGradeTitle.setText(grade);

        CardView cardPart1 = findViewById(R.id.card_part1);
        CardView cardPart2 = findViewById(R.id.card_part2);

        cardPart1.setOnClickListener(v -> {
            Intent intent = new Intent(this, UnitActivity.class);
            intent.putExtra("grade", grade);
            intent.putExtra("part", "الجزء الأول");
            intent.putExtra("partNumber", 1);
            startActivity(intent);
        });

        cardPart2.setOnClickListener(v -> {
            Intent intent = new Intent(this, UnitActivity.class);
            intent.putExtra("grade", grade);
            intent.putExtra("part", "الجزء الثاني");
            intent.putExtra("partNumber", 2);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
