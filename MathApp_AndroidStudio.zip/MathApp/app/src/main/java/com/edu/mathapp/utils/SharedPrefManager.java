package com.edu.mathapp.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {

    private static final String PREF_NAME = "MathAppPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_USER_EMAIL = "userEmail";
    private static final String KEY_USER_PHONE = "userPhone";
    private static final String KEY_USER_PASSWORD = "userPassword";

    private static SharedPrefManager instance;
    private final SharedPreferences prefs;

    private SharedPrefManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (instance == null) {
            instance = new SharedPrefManager(context.getApplicationContext());
        }
        return instance;
    }

    public void registerUser(String name, String email, String phone, String password) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_PHONE, phone);
        editor.putString(KEY_USER_PASSWORD, password);
        editor.apply();
    }

    public boolean loginUser(String email, String password) {
        String savedEmail = prefs.getString(KEY_USER_EMAIL, null);
        String savedPassword = prefs.getString(KEY_USER_PASSWORD, null);
        if (savedEmail != null && savedEmail.equals(email) &&
                savedPassword != null && savedPassword.equals(password)) {
            prefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).apply();
            return true;
        }
        return false;
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public boolean isRegistered() {
        return prefs.getString(KEY_USER_EMAIL, null) != null;
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return prefs.getString(KEY_USER_EMAIL, "");
    }

    public void logout() {
        prefs.edit().putBoolean(KEY_IS_LOGGED_IN, false).apply();
    }

    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
