package com.edu.mathapp.activities;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.edu.mathapp.R;

public class ExerciseActivity extends AppCompatActivity {

    private int unitNumber, lessonNumber;
    private String unitName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);

        unitNumber = getIntent().getIntExtra("unitNumber", 1);
        lessonNumber = getIntent().getIntExtra("lessonNumber", 1);
        unitName = getIntent().getStringExtra("unitName");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("حل التدرب");
        }

        TextView tvExerciseTitle = findViewById(R.id.tv_exercise_title);
        tvExerciseTitle.setText("تدرب الدرس " + lessonNumber + " - الوحدة " + unitNumber);

        TextView tvExerciseSubtitle = findViewById(R.id.tv_exercise_subtitle);
        tvExerciseSubtitle.setText(unitName);

        setupQuestionCards();
    }

    private void setupQuestionCards() {
        int[] cardIds = {
            R.id.card_q1, R.id.card_q2, R.id.card_q3,
            R.id.card_q4, R.id.card_q5, R.id.card_q6
        };

        for (int i = 0; i < 6; i++) {
            CardView card = findViewById(cardIds[i]);
            final int qNum = i + 1;
            card.setOnClickListener(v -> {
                Toast.makeText(this,
                    "حل السؤال " + qNum + " - قريباً", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
