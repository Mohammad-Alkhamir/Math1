package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.edu.mathapp.R;

public class LessonActivity extends AppCompatActivity {

    private String grade, part, unitName;
    private int partNumber, unitNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson);

        grade = getIntent().getStringExtra("grade");
        part = getIntent().getStringExtra("part");
        partNumber = getIntent().getIntExtra("partNumber", 1);
        unitNumber = getIntent().getIntExtra("unitNumber", 1);
        unitName = getIntent().getStringExtra("unitName");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("الوحدة " + unitNumber);
        }

        TextView tvUnitTitle = findViewById(R.id.tv_unit_title);
        tvUnitTitle.setText("الوحدة " + unitNumber + ": " + unitName);

        setupLessonCards();
    }

    private void setupLessonCards() {
        int[] cardIds = {
            R.id.card_lesson1, R.id.card_lesson2, R.id.card_lesson3,
            R.id.card_lesson4, R.id.card_lesson5
        };

        for (int i = 0; i < 5; i++) {
            CardView card = findViewById(cardIds[i]);
            final int lessonNum = i + 1;
            card.setOnClickListener(v -> {
                Intent intent = new Intent(this, LessonDetailActivity.class);
                intent.putExtra("grade", grade);
                intent.putExtra("part", part);
                intent.putExtra("partNumber", partNumber);
                intent.putExtra("unitNumber", unitNumber);
                intent.putExtra("unitName", unitName);
                intent.putExtra("lessonNumber", lessonNum);
                startActivity(intent);
            });
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
