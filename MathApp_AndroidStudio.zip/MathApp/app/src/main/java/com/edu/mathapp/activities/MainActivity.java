package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.edu.mathapp.R;
import com.edu.mathapp.utils.SharedPrefManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        String userName = SharedPrefManager.getInstance(this).getUserName();
        TextView tvWelcome = findViewById(R.id.tv_welcome);
        tvWelcome.setText("أهلاً، " + userName);

        CardView cardThirdGrade = findViewById(R.id.card_third_grade);
        cardThirdGrade.setOnClickListener(v -> {
            Intent intent = new Intent(this, PartActivity.class);
            intent.putExtra("grade", "الثالث الثانوي العلمي");
            startActivity(intent);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            SharedPrefManager.getInstance(this).logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
