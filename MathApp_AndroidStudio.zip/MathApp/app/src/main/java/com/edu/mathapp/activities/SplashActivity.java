package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.edu.mathapp.R;
import com.edu.mathapp.utils.SharedPrefManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.iv_logo);
        TextView title = findViewById(R.id.tv_app_title);
        TextView subtitle = findViewById(R.id.tv_subtitle);

        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        Animation slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up);

        logo.startAnimation(fadeIn);
        title.startAnimation(slideUp);
        subtitle.startAnimation(slideUp);

        new Handler().postDelayed(() -> {
            SharedPrefManager spm = SharedPrefManager.getInstance(this);
            Intent intent;
            if (!spm.isRegistered()) {
                intent = new Intent(this, RegisterActivity.class);
            } else if (!spm.isLoggedIn()) {
                intent = new Intent(this, LoginActivity.class);
            } else {
                intent = new Intent(this, MainActivity.class);
            }
            startActivity(intent);
            finish();
        }, 2500);
    }
}
