package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.edu.mathapp.R;
import com.edu.mathapp.utils.SharedPrefManager;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etPassword, etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPhone = findViewById(R.id.et_phone);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register);
        tvLogin = findViewById(R.id.tv_login);

        btnRegister.setOnClickListener(v -> registerUser());

        tvLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void registerUser() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            etName.setError("الاسم مطلوب");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            etEmail.setError("البريد الإلكتروني مطلوب");
            return;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("البريد الإلكتروني غير صحيح");
            return;
        }
        if (TextUtils.isEmpty(phone)) {
            etPhone.setError("رقم الهاتف مطلوب");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("كلمة المرور مطلوبة");
            return;
        }
        if (password.length() < 6) {
            etPassword.setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
            return;
        }
        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("كلمتا المرور غير متطابقتين");
            return;
        }

        SharedPrefManager.getInstance(this).registerUser(name, email, phone, password);
        Toast.makeText(this, "تم التسجيل بنجاح!", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
