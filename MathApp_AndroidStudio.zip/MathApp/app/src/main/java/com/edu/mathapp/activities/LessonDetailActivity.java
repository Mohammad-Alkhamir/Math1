package com.edu.mathapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.edu.mathapp.R;

public class LessonDetailActivity extends AppCompatActivity {

    private String grade, part, unitName;
    private int partNumber, unitNumber, lessonNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson_detail);

        grade = getIntent().getStringExtra("grade");
        part = getIntent().getStringExtra("part");
        partNumber = getIntent().getIntExtra("partNumber", 1);
        unitNumber = getIntent().getIntExtra("unitNumber", 1);
        unitName = getIntent().getStringExtra("unitName");
        lessonNumber = getIntent().getIntExtra("lessonNumber", 1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("الدرس " + lessonNumber);
        }

        TextView tvLessonTitle = findViewById(R.id.tv_lesson_title);
        tvLessonTitle.setText("الوحدة " + unitNumber + " - الدرس " + lessonNumber);

        TextView tvLessonSubtitle = findViewById(R.id.tv_lesson_subtitle);
        tvLessonSubtitle.setText(unitName);

        CardView cardExplain = findViewById(R.id.card_explain);
        CardView cardExercise = findViewById(R.id.card_exercise);

        cardExplain.setOnClickListener(v -> {
            // Placeholder for lesson explanation (can be extended)
            android.widget.Toast.makeText(this,
                "شرح الدرس " + lessonNumber + " - قريباً", android.widget.Toast.LENGTH_SHORT).show();
        });

        cardExercise.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseActivity.class);
            intent.putExtra("grade", grade);
            intent.putExtra("part", part);
            intent.putExtra("partNumber", partNumber);
            intent.putExtra("unitNumber", unitNumber);
            intent.putExtra("unitName", unitName);
            intent.putExtra("lessonNumber", lessonNumber);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
